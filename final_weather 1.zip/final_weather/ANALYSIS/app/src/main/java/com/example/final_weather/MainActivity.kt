@file:Suppress("DEPRECATION")

package com.example.final_weather

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.gson.Gson
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class WeatherResponse(val name: String, val main: MainInfo, val weather: List<WeatherInfo>, val wind: WindInfo)
data class MainInfo(val temp: Double, val tempmin: Double, val tempmax: Double, val humidity: Int)
data class WeatherInfo(val description: String, val icon: String)
data class WindInfo(val speed: Double)
data class ForecastResponse(val daily: List<DailyForecast>)
data class DailyForecast(val dt: Long, val temp: DailyTemp, val weather: List<WeatherInfo>)
data class DailyTemp(val day: Double)

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    private val apiKey = "99a8dfba04ae1f4c0acb9308413ffac1"
    private val locationPermissionCode = 100
    private lateinit var locationManager: LocationManager

    private lateinit var textViewCity: TextView
    private lateinit var textViewTodayDate: TextView
    private lateinit var textViewTemperature: TextView
    private lateinit var textViewWeatherDescription: TextView
    private lateinit var textViewMinMaxTemp: TextView
    private lateinit var textViewRainPercent: TextView
    private lateinit var textViewWindSpeed: TextView
    private lateinit var textViewHumidityPercent: TextView
    private lateinit var imageViewWeatherIcon: ImageView
    private lateinit var recyclerViewDailyForecast: RecyclerView
    private lateinit var dailyForecastAdapter: DailyForecastAdapter
    private lateinit var textViewTemperatureUnit: TextView
    private lateinit var textViewMinMaxTempUnit: TextView
    private lateinit var textViewNext7Days: TextView

    private var fullForecastList: List<DailyForecast> = emptyList()

    @SuppressLint("DiscouragedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(resources.getIdentifier("activity_main", "layout", packageName))

        textViewCity =
            findViewById(resources.getIdentifier("textViewCity", "id", packageName))!!
        textViewTodayDate =
            findViewById(resources.getIdentifier("textViewTodayDate", "id", packageName))!!
        textViewTemperature =
            findViewById(resources.getIdentifier("textViewTemperature", "id", packageName))!!
        textViewWeatherDescription = findViewById(resources.getIdentifier("textViewWeatherDescription", "id", packageName))!!
        textViewMinMaxTemp =
            findViewById(resources.getIdentifier("textViewMinMaxTemp", "id", packageName))!!
        textViewRainPercent =
            findViewById(resources.getIdentifier("textViewRainPercent", "id", packageName))!!
        textViewWindSpeed =
            findViewById(resources.getIdentifier("textViewWindSpeed", "id", packageName))!!
        textViewHumidityPercent = findViewById(resources.getIdentifier("textViewHumidityPercent", "id", packageName))!!
        imageViewWeatherIcon =
            findViewById(resources.getIdentifier("imageViewCloud", "id", packageName))!!
        recyclerViewDailyForecast = findViewById(resources.getIdentifier("recyclerViewDailyForecast", "id", packageName))!!
        recyclerViewDailyForecast.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        dailyForecastAdapter = DailyForecastAdapter(emptyList())
        recyclerViewDailyForecast.adapter = dailyForecastAdapter
        textViewTemperatureUnit = findViewById(resources.getIdentifier("textViewTemperatureUnit", "id", packageName))!!
        textViewMinMaxTempUnit = findViewById(resources.getIdentifier("textViewMinMaxTempUnit", "id", packageName))!!
        textViewNext7Days =
            findViewById(resources.getIdentifier("textViewNext7Days", "id", packageName))!!

        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), locationPermissionCode)
        } else {
            getCurrentLocation()
        }

        textViewNext7Days.setOnClickListener {
            showFullForecastDialog()
        }
    }

    @SuppressLint("DiscouragedApi")
    private fun showFullForecastDialog() {
        if (fullForecastList.isNotEmpty()) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Next 7 Days Forecast")

            val layout = LinearLayout(this)
            layout.orientation = LinearLayout.VERTICAL

            val inflater = LayoutInflater.from(this)

            fullForecastList.forEach { forecast ->
                val itemView = inflater.inflate(resources.getIdentifier("item_daily_forecast_detail", "layout", packageName), layout, false)

                val dayTextView: TextView = itemView.findViewById(resources.getIdentifier("textViewDailyDateDetail", "id", packageName))
                val iconImageView: ImageView = itemView.findViewById(resources.getIdentifier("imageViewDailyWeatherIcon", "id", packageName))
                val tempTextView: TextView = itemView.findViewById(resources.getIdentifier("textViewDailyTemperatureDetail", "id", packageName))
                val descriptionTextView: TextView = itemView.findViewById(resources.getIdentifier("textViewDailyDescriptionDetail", "id", packageName))

                val sdf = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
                val date = Date(forecast.dt * 1000)
                dayTextView.text = sdf.format(date)
                tempTextView.text = String.format(Locale.getDefault(), "%.0f°C", forecast.temp.day)
                descriptionTextView.text = forecast.weather[0].description.capitalize(Locale.getDefault())

                val iconCode = forecast.weather[0].icon
                val iconUrl = "https://openweathermap.org/img/wn/${iconCode}@2x.png"
                Glide.with(this)
                    .load(iconUrl)
                    .into(iconImageView)

                layout.addView(itemView)
            }

            builder.setView(layout)
            builder.setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        } else {
            Toast.makeText(this, "Forecast data not available", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentLocation() {
        try {
            val location: Location? = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            location?.let {
                FetchWeatherTask().execute(it.latitude, it.longitude, "weather")
                FetchWeatherTask().execute(it.latitude, it.longitude, "forecast")
            } ?: run {
                val networkLocation: Location? = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                networkLocation?.let {
                    FetchWeatherTask().execute(it.latitude, it.longitude, "weather")
                    FetchWeatherTask().execute(it.latitude, it.longitude, "forecast")
                } ?: run {
                    Toast.makeText(this, "Could not get location", Toast.LENGTH_SHORT).show()
                    FetchWeatherTask().execute(31.95, 35.93, "weather")
                    FetchWeatherTask().execute(31.95, 35.93, "forecast")
                }
            }
        } catch (e: SecurityException) {
            Toast.makeText(this, "Location permission not granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Location permission is required", Toast.LENGTH_SHORT).show()
                FetchWeatherTask().execute(31.95, 35.93, "weather")
                FetchWeatherTask().execute(31.95, 35.93, "forecast")
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    inner class FetchWeatherTask : AsyncTask<Any, Void, Pair<String, String?>>() {
        private var requestType: String? = null

        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: Any?): Pair<String, String?> {
            val latitude = params[0] as Double
            val longitude = params[1] as Double
            requestType = params[2] as String
            val apiUrl = when (requestType) {
                "weather" -> "https://api.openweathermap.org/data/2.5/weather?lat=$latitude&lon=$longitude&app's=$apiKey&units=metric"
                "forecast" -> "https://api.openweathermap.org/data/2.5/onecall?lat=$latitude&lon=$longitude&app's=$apiKey&units=metric&exclude=current,minutely,hourly,alerts"
                else -> null
            }

            val result: String?
            var urlConnection: HttpURLConnection? = null
            try {
                val url = URL(apiUrl)
                urlConnection = url.openConnection() as HttpURLConnection
                val inputStream = urlConnection.inputStream
                val bufferedReader = BufferedReader(InputStreamReader(inputStream))
                val stringBuilder = StringBuilder()
                var line: String?
                while (bufferedReader.readLine().also { line = it } != null) {
                    stringBuilder.append(line).append("\n")
                }
                result = stringBuilder.toString()
            } catch (e: IOException) {
                Log.e("HTTP Error", e.toString())
                return Pair(requestType!!, null)
            } finally {
                urlConnection?.disconnect()
            }
            return Pair(requestType!!, result)
        }

        @Deprecated("Deprecated in Java")
        @SuppressLint("DefaultLocale")
        override fun onPostExecute(resultPair: Pair<String, String?>) {
            val result = resultPair.second
            when (resultPair.first) {
                "weather" -> {
                    if (result != null) {
                        val weatherResponse = Gson().fromJson(result, WeatherResponse::class.java)
                        textViewCity.text = weatherResponse.name
                        textViewTemperature.text = String.format(Locale.getDefault(), "%.0f", weatherResponse.main.temp)
                        textViewWeatherDescription.text = weatherResponse.weather[0].description.capitalize(Locale.getDefault())
                        textViewMinMaxTemp.text = String.format(Locale.getDefault(), "%.0f", weatherResponse.main.tempmin)
                        textViewTemperatureUnit.text = "°C"
                        textViewMinMaxTempUnit.text = "°C"
                        textViewHumidityPercent.text = String.format(Locale.getDefault(), "%d%%", weatherResponse.main.humidity)
                        textViewWindSpeed.text = String.format(Locale.getDefault(), "%.1f كم/س", weatherResponse.wind.speed)

                        val iconCode = weatherResponse.weather[0].icon
                        val iconUrl = "https://openweathermap.org/img/wn/${iconCode}@2x.png"
                        Glide.with(this@MainActivity)
                            .load(iconUrl)
                            .into(imageViewWeatherIcon)

                        val sdf = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
                        val currentDate = sdf.format(Date())
                        textViewTodayDate.text = currentDate
                    } else {
                        Toast.makeText(this@MainActivity, "Could not retrieve weather data", Toast.LENGTH_SHORT).show()
                    }
                }
                "forecast" -> {
                    if (result != null) {
                        val forecastResponse = Gson().fromJson(result, ForecastResponse::class.java)
                        val dailyForecasts = forecastResponse.daily.take(7)
                        fullForecastList = dailyForecasts
                        dailyForecastAdapter.updateData(dailyForecasts)
                    } else {
                        Toast.makeText(this@MainActivity, "Could not retrieve forecast data", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}

class DailyForecastAdapter(private var forecastList: List<DailyForecast>) :
    RecyclerView.Adapter<DailyForecastAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        @SuppressLint("DiscouragedApi")
        val dayTextView: TextView = itemView.findViewById(itemView.context.resources.getIdentifier("textViewDay", "id", itemView.context.packageName))
        @SuppressLint("DiscouragedApi")
        val iconImageView: ImageView = itemView.findViewById(itemView.context.resources.getIdentifier("imageViewDailyWeatherIcon", "id", itemView.context.packageName))
        @SuppressLint("DiscouragedApi")
        val tempTextView: TextView = itemView.findViewById(itemView.context.resources.getIdentifier("textViewDailyTemperature", "id", itemView.context.packageName))
    }

    @SuppressLint("DiscouragedApi")
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(parent.context.resources.getIdentifier("item_daily_forecast", "layout", parent.context.packageName), parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("DefaultLocale")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val forecast = forecastList[position]

        val sdf = SimpleDateFormat("EEE", Locale.getDefault())
        val date = Date(forecast.dt * 1000)
        holder.dayTextView.text = sdf.format(date)

        holder.tempTextView.text = String.format(Locale.getDefault(), "%.0f°C", forecast.temp.day)

        val iconCode = forecast.weather[0].icon
        val iconUrl = "https://openweathermap.org/img/wn/${iconCode}@2x.png"
        Glide.with(holder.itemView.context)
            .load(iconUrl)
            .into(holder.iconImageView)
    }

    override fun getItemCount() = forecastList.size

    @SuppressLint("NotifyDataSetChanged")
    fun updateData(newForecastList: List<DailyForecast>) {
        forecastList = newForecastList
        notifyDataSetChanged()
    }
}